function Write-JsonFile($Path, $Value) {
    $tmp = "$Path.tmp"
    [IO.File]::WriteAllText($tmp, ($Value | ConvertTo-Json -Depth 8), [Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath $tmp -Destination $Path -Force
}
function Read-JsonFile($Path) {
    if (Test-Path -LiteralPath $Path) { Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json }
}
function Assert-Config($Config, [switch]$AllowUndetectedProxy) {
    if ($Config.Server -notmatch '^[A-Za-z0-9][A-Za-z0-9.-]*$') { throw '服务器请填 IPv4 地址或普通主机名，不要填命令。' }
    if ($Config.User -notmatch '^[A-Za-z_][A-Za-z0-9_.-]*$') { throw '请填写有效的 Linux 用户名。' }
    foreach ($name in @('SshPort','ProxyPort','RemotePort')) {
        if ($name -eq 'ProxyPort' -and $AllowUndetectedProxy -and [string]$Config.ProxyPort -eq '0') { continue }
        $number = 0
        if (-not [int]::TryParse([string]$Config.$name, [ref]$number) -or $number -lt 1 -or $number -gt 65535) { throw "$name 必须是 1–65535 的整数。" }
    }
}
function Quote-WindowsArgument([string]$Value) {
    # Windows CommandLineToArgvW quoting, including spaces and trailing backslashes.
    return '"' + [regex]::Replace([regex]::Replace($Value, '(\\*)"', '$1$1\"'), '(\\+)$', '$1$1') + '"'
}
function Get-SshArguments($Config, [string]$RemoteCommand) {
    @('-T','-o','ExitOnForwardFailure=yes','-o','ServerAliveInterval=30','-o','ServerAliveCountMax=3',
      '-o','ConnectTimeout=15','-o','ControlMaster=no','-o','ControlPath=none',
      '-p',[string]$Config.SshPort,'-R',"127.0.0.1:$($Config.RemotePort):127.0.0.1:$($Config.ProxyPort)",
      "$($Config.User)@$($Config.Server)",$RemoteCommand)
}
function Test-LocalProxy([int]$Port) {
    $client = [Net.Sockets.TcpClient]::new()
    try {
        $connect = $client.ConnectAsync('127.0.0.1', $Port)
        if (-not $connect.Wait(1800)) { throw '连接超时' }
        if (-not $client.Connected) { throw '未连接' }
    } catch { throw "当前电脑 127.0.0.1:$Port 没有可连接的代理。请先打开代理软件并核对端口。" }
    finally { $client.Dispose() }
}
function Get-ConflictingTunnel($Config) {
    $pattern = '127\.0\.0\.1:' + [regex]::Escape([string]$Config.RemotePort) + ':127\.0\.0\.1:'
    # Conservatively block matching local forwarders, even when their host alias differs.
    @(Get-CimInstance Win32_Process -Filter "Name='ssh.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -match $pattern })
}
function Test-OwnedProcess($State, [string]$Prefix) {
    try {
        $idValue = $State.("${Prefix}Pid")
        $startValue = $State.("${Prefix}Start")
        if (-not $idValue -or -not $startValue) { return $false }
        $process = Get-Process -Id $idValue -ErrorAction Stop
        return $process.StartTime.ToUniversalTime().Ticks.ToString() -eq [string]$startValue
    } catch { return $false }
}
function Get-CodeArguments([string]$Alias) {
    @('--new-window','--remote',"ssh-remote+$Alias")
}
function Find-CodeExecutable {
    $candidates=[Collections.Generic.List[string]]::new()
    $cmd=Get-Command code.cmd -ErrorAction SilentlyContinue
    if($cmd) { $candidates.Add((Join-Path (Split-Path (Split-Path $cmd.Source)) 'Code.exe')) }
    foreach($regPath in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\Code.exe','HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\Code.exe')) {
        if(Test-Path $regPath) { $value=(Get-Item $regPath).GetValue(''); if($value){$candidates.Add($value)} }
    }
    foreach($path in @("$env:LOCALAPPDATA\Programs\Microsoft VS Code\Code.exe","$env:ProgramFiles\Microsoft VS Code\Code.exe","${env:ProgramFiles(x86)}\Microsoft VS Code\Code.exe")) { $candidates.Add($path) }
    $candidates | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
}
function Get-LoopbackProxyPort([string]$Value) {
    # Accept only local HTTP proxy endpoints. Never use remote proxy credentials or PAC URLs.
    foreach($part in ($Value -split ';')) {
        $item=$part.Trim()
        if($item -match '^(http|https)=(.+)$') { $item=$Matches[2] }
        if($item -match '^(?:http://)?(?:127\.0\.0\.1|localhost):(\d{1,5})/?$') {
            $number=[int]$Matches[1]
            if($number -ge 1 -and $number -le 65535){$number}
        }
    }
}
function Get-ProxyCandidates([int]$SavedPort=0) {
    $candidates=[Collections.Generic.List[object]]::new()
    $settings=Get-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -ErrorAction SilentlyContinue
    if($settings.ProxyEnable -eq 1) {
        foreach($port in @(Get-LoopbackProxyPort $settings.ProxyServer)){ $candidates.Add([pscustomobject]@{Port=$port; Source='Windows 系统代理'}) }
    }
    foreach($name in @('HTTP_PROXY','HTTPS_PROXY')) {
        foreach($port in @(Get-LoopbackProxyPort ([Environment]::GetEnvironmentVariable($name)))){ $candidates.Add([pscustomobject]@{Port=$port; Source='代理环境变量'}) }
    }
    if($SavedPort -ge 1 -and $SavedPort -le 65535){$candidates.Add([pscustomobject]@{Port=$SavedPort;Source='当前电脑上次使用'})}
    # Find listening ports owned by common proxy engines; no command lines or credentials are read.
    try {
        $ids=@(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match '^(mihomo|clash|clash-meta|verge-mihomo|sing-box|xray|v2ray|shadowsocks)(-|$)' } | Select-Object -ExpandProperty Id)
        if($ids.Count) {
            foreach($listener in @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object { $_.OwningProcess -in $ids -and $_.LocalAddress -in @('127.0.0.1','0.0.0.0','::') } | Select-Object -First 16)) {
                $candidates.Add([pscustomobject]@{Port=[int]$listener.LocalPort;Source='代理软件监听端口'})
            }
        }
    } catch {}
    foreach($port in @(7897,7890,10809,8080,1080)){ $candidates.Add([pscustomobject]@{Port=$port;Source='常用代理端口'}) }
    $seen=@{}
    foreach($candidate in $candidates){ if(-not $seen.ContainsKey($candidate.Port)){ $seen[$candidate.Port]=$true; $candidate } }
}
function Ensure-WorkbenchHost($Config, [string]$ConfigFile = (Join-Path $env:USERPROFILE '.ssh\config')) {
    $hash = [Security.Cryptography.SHA256]::Create()
    try { $key = ([BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes("$($Config.Server)|$($Config.User)|$($Config.SshPort)")))).Replace('-','').Substring(0,12).ToLower() }
    finally { $hash.Dispose() }
    $alias = "rl-workbench-$key"
    $path = $ConfigFile
    $sshDir = Split-Path -Parent $path
    $existing = ''
    if (Test-Path -LiteralPath $path) { $existing=[IO.File]::ReadAllText($path) }
    if ($existing -notmatch "(?m)^Host $alias\s*$") {
        [void][IO.Directory]::CreateDirectory($sshDir)
        if (Test-Path -LiteralPath $path) { Copy-Item -LiteralPath $path -Destination "$path.rl-workbench.$([DateTime]::Now.ToString('yyyyMMddHHmmssfff')).bak" }
        # Prepend a narrowly scoped alias; original content is retained verbatim.
        $block = "# BEGIN RL-WORKBENCH $alias`r`nHost $alias`r`n  HostName $($Config.Server)`r`n  User $($Config.User)`r`n  Port $($Config.SshPort)`r`n# END RL-WORKBENCH $alias`r`n`r`n"
        [IO.File]::WriteAllText($path, $block+$existing, [Text.UTF8Encoding]::new($false))
    }
    return $alias
}
