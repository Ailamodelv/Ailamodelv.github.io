param([switch]$SmokeTest)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
. "$PSScriptRoot\Common.ps1"
$dataRoot=Join-Path $env:LOCALAPPDATA 'RLWorkbench'
[void][IO.Directory]::CreateDirectory($dataRoot)
$configPath=Join-Path $dataRoot 'settings.json'
$activePath=Join-Path $dataRoot 'active.json'
$serverPath=Join-Path $PSScriptRoot 'server.json'
$script:sessionDir=$null; $script:autoOpen=$false; $script:activeConfig=$null
$script:proxyPort=0; $script:sshPort=22; $script:codePath=''; $script:discovery=$null
$script:connected=$false; $script:controls=@{}; $script:savedPort=0
$script:mutex=[Threading.Mutex]::new($false,'Local\RLWorkbench.Desktop')
if(-not $script:mutex.WaitOne(0)){[Windows.Forms.MessageBox]::Show('工作台已打开，请切换到已有窗口。','强化学习工作台') | Out-Null;exit}
function Show-Error($Text){[Windows.Forms.MessageBox]::Show([string]$Text,'操作提示',[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Information)|Out-Null}
function Read-Fields([switch]$AllowUndetectedProxy){
    $cfg=[pscustomobject]@{Server=$script:controls.Server.Text.Trim();User=$script:controls.User.Text.Trim();RemotePort=$script:controls.RemotePort.Text.Trim();SshPort=$script:sshPort;ProxyPort=$script:proxyPort}
    Assert-Config $cfg -AllowUndetectedProxy:$AllowUndetectedProxy
    return $cfg
}
function Save-Settings($cfg){
    Write-JsonFile $serverPath @{Server=$cfg.Server;User=$cfg.User;RemotePort=$cfg.RemotePort;SshPort=$cfg.SshPort}
    Write-JsonFile $configPath @{ProxyPort=$cfg.ProxyPort;CodePath=$script:codePath}
}
function Open-Server($cfg){
    $exe=$script:codePath
    if(-not $exe -or -not(Test-Path -LiteralPath $exe)){ $exe=Find-CodeExecutable }
    if(-not $exe){throw '未找到 VS Code。安装后点“一键检测本机”；便携版 VS Code 可在高级设置中选择。'}
    $alias=Ensure-WorkbenchHost $cfg
    $arguments=Get-CodeArguments $alias
    Start-Process -FilePath $exe -ArgumentList ($arguments | ForEach-Object {Quote-WindowsArgument $_}) | Out-Null
}
function Begin-Detection {
    if($script:connected){Show-Error '通道运行中不能更换代理。请先断开，再重新检测。';return}
    $script:discovery=Join-Path $dataRoot ('detect-'+[Guid]::NewGuid().ToString('N')+'.json')
    $proxyLabel.Text='正在检测本机代理和软件，请稍候…'
    $detect.Enabled=$false; $connect.Enabled=$false; $advanced.Enabled=$false
    $shell=Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $launchArgs=@('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',(Quote-WindowsArgument "$PSScriptRoot\Discover.ps1"),'-OutputPath',(Quote-WindowsArgument $script:discovery),'-SavedPort',[string]$script:savedPort)
    $script:detectProcess=Start-Process -FilePath $shell -ArgumentList $launchArgs -WindowStyle Hidden -PassThru
    $script:detectStarted=Get-Date
}
function Restore-Session {
    $a=Read-JsonFile $activePath
    if($a -and(Test-Path -LiteralPath $a.SessionDir)){
        $script:sessionDir=$a.SessionDir
        $s=Read-JsonFile (Join-Path $script:sessionDir 'state.json')
        if($s -and ((Test-OwnedProcess $s 'Worker') -or(Test-OwnedProcess $s 'Ssh'))){
            $script:connected=$true
            $script:activeConfig=Read-JsonFile (Join-Path $script:sessionDir 'config.json')
            foreach($n in $script:controls.Keys){$script:controls[$n].Text=[string]$script:activeConfig.$n}
            $script:proxyPort=[int]$script:activeConfig.ProxyPort;$script:sshPort=[int]$script:activeConfig.SshPort
        }else{$script:sessionDir=$null}
    }
}
$form=[Windows.Forms.Form]::new();$form.Text='强化学习工作台 · 便携版 2.0'
$form.ClientSize=[Drawing.Size]::new(800,630);$form.MinimumSize=[Drawing.Size]::new(816,669)
$form.StartPosition='CenterScreen';$form.Font=[Drawing.Font]::new('Microsoft YaHei UI',10)
$form.BackColor=[Drawing.Color]::FromArgb(245,247,250);$form.AutoScaleMode=[Windows.Forms.AutoScaleMode]::Dpi
function Add-Label($text,$x,$y,$w,$h){$c=[Windows.Forms.Label]::new();$c.Text=$text;$c.SetBounds($x,$y,$w,$h);$form.Controls.Add($c);return $c}
function Add-Button($text,$x,$y,$w){$c=[Windows.Forms.Button]::new();$c.Text=$text;$c.SetBounds($x,$y,$w,40);$c.FlatStyle='Flat';$c.BackColor=[Drawing.Color]::White;$form.Controls.Add($c);return $c}
$title=Add-Label '换一台电脑，也能接着用' 28 20 740 36
$title.Font=[Drawing.Font]::new('Microsoft YaHei UI',17,[Drawing.FontStyle]::Bold)
$null=Add-Label '先打开代理软件；校外请先连接学校 VPN。服务器信息只需填一次。' 30 64 740 30
foreach($field in @(@('Server','服务器地址',30,280),@('User','用户名',330,225),@('RemotePort','服务器代理入口',575,185))){
    $null=Add-Label $field[1] $field[2] 110 $field[3] 24
    $box=[Windows.Forms.TextBox]::new();$box.SetBounds($field[2],139,$field[3],30);$box.AccessibleName=$field[1]
    $form.Controls.Add($box);$script:controls[$field[0]]=$box
}
$null=Add-Label '当前电脑 · 自动识别' 30 193 500 28
$proxyLabel=Add-Label '打开代理软件后，点击右侧“一键检测本机”。' 30 229 515 46
$softwareLabel=Add-Label '自动查找代理、VS Code 和 SSH，无需填写本机 IP。' 30 282 730 40
$detect=Add-Button '一键检测本机' 570 229 190
$advanced=Add-Button '高级设置…' 570 327 190
$localHelp=Add-Label '代理端口会自动选择；没有识别到时，可在高级设置手动填写。' 30 330 525 38
$connect=Add-Button '连接服务器' 30 391 220
$connect.BackColor=[Drawing.Color]::FromArgb(32,100,210);$connect.ForeColor=[Drawing.Color]::White
$open=Add-Button '仅打开 VS Code' 265 391 170
$check=Add-Button '重新检查网络' 450 391 165
$stop=Add-Button '断开' 630 391 130
$status=Add-Label '准备就绪后点击“连接服务器”，密码会在 SSH 窗口中询问。' 30 448 730 62
$status.BackColor=[Drawing.Color]::FromArgb(231,237,247);$status.Padding=[Windows.Forms.Padding]::new(10)
$detail=Add-Label '连接后在 VS Code 中“打开文件夹”，不用提前填写 Linux 项目目录。' 30 520 730 30
$guide=Add-Button '使用指南' 30 565 140
$save=Add-Button '保存服务器信息' 185 565 185
$footer=Add-Label '关闭面板不关闭通道；换电脑前请点“断开”。' 390 570 375 42

function Show-Advanced {
    $dialog=[Windows.Forms.Form]::new();$dialog.Text='高级设置 · 一般不需要修改';$dialog.ClientSize=[Drawing.Size]::new(610,285)
    $dialog.StartPosition='CenterParent';$dialog.Font=$form.Font;$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false
    $lbl=[Windows.Forms.Label]::new();$lbl.Text='SSH 是服务器的远程登录入口，默认 22。只有管理员改过时才需要改。';$lbl.SetBounds(20,15,570,45);$dialog.Controls.Add($lbl)
    $sshLabel=[Windows.Forms.Label]::new();$sshLabel.Text='SSH 端口';$sshLabel.SetBounds(20,67,120,25);$dialog.Controls.Add($sshLabel)
    $sshBox=[Windows.Forms.TextBox]::new();$sshBox.Text=[string]$script:sshPort;$sshBox.SetBounds(150,64,130,30);$dialog.Controls.Add($sshBox)
    $portLabel=[Windows.Forms.Label]::new();$portLabel.Text='手动代理端口';$portLabel.SetBounds(20,108,130,25);$dialog.Controls.Add($portLabel)
    $portBox=[Windows.Forms.TextBox]::new();$portBox.Text=if($script:proxyPort){[string]$script:proxyPort}else{''};$portBox.SetBounds(150,105,130,30);$dialog.Controls.Add($portBox)
    $hint=[Windows.Forms.Label]::new();$hint.Text='留空则需要一键检测；手动值会检查本机监听。';$hint.SetBounds(295,106,295,42);$dialog.Controls.Add($hint)
    $pathBox=[Windows.Forms.TextBox]::new();$pathBox.Text=$script:codePath;$pathBox.ReadOnly=$true;$pathBox.SetBounds(20,163,395,30);$dialog.Controls.Add($pathBox)
    $browse=[Windows.Forms.Button]::new();$browse.Text='选择 VS Code…';$browse.SetBounds(430,161,160,32);$dialog.Controls.Add($browse)
    $browse.Add_Click({$picker=[Windows.Forms.OpenFileDialog]::new();$picker.Filter='VS Code (Code.exe)|Code.exe';if($picker.ShowDialog() -eq 'OK'){$pathBox.Text=$picker.FileName};$picker.Dispose()})
    $ok=[Windows.Forms.Button]::new();$ok.Text='应用';$ok.SetBounds(430,225,160,38);$dialog.Controls.Add($ok)
    $ok.Add_Click({
        try{
            $newPort=0;if($portBox.Text.Trim()){$newPort=[int]$portBox.Text.Trim()}
            $cfg=Read-Fields -AllowUndetectedProxy;$cfg.SshPort=$sshBox.Text.Trim();$cfg.ProxyPort=$newPort
            Assert-Config $cfg -AllowUndetectedProxy
            if($newPort){Test-LocalProxy $newPort}
            $script:sshPort=[int]$cfg.SshPort;$script:proxyPort=$newPort;$script:savedPort=$newPort;$script:codePath=$pathBox.Text
            $proxyLabel.Text=if($newPort){"手动代理：127.0.0.1:$newPort（已检查监听，外网待连接后验证）"}else{'未指定代理，请点击“一键检测本机”。'}
            $dialog.Close()
        }catch{Show-Error $_.Exception.Message}
    })
    [void]$dialog.ShowDialog($form);$dialog.Dispose()
}
try{
    $cfg=Read-JsonFile $serverPath;if(-not $cfg){$cfg=Read-JsonFile "$PSScriptRoot\defaults.json"}
    foreach($name in $script:controls.Keys){$script:controls[$name].Text=[string]$cfg.$name};$script:sshPort=[int]$cfg.SshPort
    $prefs=Read-JsonFile $configPath
    if($prefs){$script:savedPort=[int]$prefs.ProxyPort;if($prefs.CodePath -and(Test-Path -LiteralPath $prefs.CodePath)){$script:codePath=$prefs.CodePath}}
    $null=Read-Fields -AllowUndetectedProxy
    Restore-Session
    if($script:connected){$proxyLabel.Text="已有通道：当前电脑 127.0.0.1:$($script:proxyPort)"}
}catch{Show-Error $_.Exception.Message}
$save.Add_Click({try{Save-Settings (Read-Fields -AllowUndetectedProxy);$status.Text='服务器信息已保存；复制整个工具文件夹到新电脑即可带走。'}catch{Show-Error $_.Exception.Message}})
$guide.Add_Click({Start-Process notepad.exe -ArgumentList (Quote-WindowsArgument "$PSScriptRoot\使用指南.md")})
$detect.Add_Click({try{Begin-Detection}catch{Show-Error $_.Exception.Message}})
$advanced.Add_Click({Show-Advanced})
$open.Add_Click({try{Open-Server (Read-Fields -AllowUndetectedProxy)}catch{Show-Error $_.Exception.Message}})
$connect.Add_Click({
    try{
        if(-not $script:proxyPort){Begin-Detection;$status.Text='先自动检测当前电脑，完成后再点击“连接服务器”。';return}
        $cfg=Read-Fields;Test-LocalProxy $cfg.ProxyPort
        if((Get-ConflictingTunnel $cfg).Count){throw '已有代理通道。请先关闭旧 SSH 代理窗口，再重新连接；若只需编辑，点击“仅打开 VS Code”。'}
        Save-Settings $cfg
        $script:sessionDir=Join-Path $dataRoot ([Guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory($script:sessionDir)
        Write-JsonFile (Join-Path $script:sessionDir 'config.json') $cfg
        Write-JsonFile $activePath @{SessionDir=$script:sessionDir}
        $script:activeConfig=$cfg;$script:autoOpen=$true;$script:launchAt=Get-Date
        $status.Text='请在弹出的 SSH 窗口输入密码，保留该窗口。'
        $shell=Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
        $launchArgs=@('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File',(Quote-WindowsArgument "$PSScriptRoot\Tunnel.ps1"),'-SessionDir',(Quote-WindowsArgument $script:sessionDir))
        Start-Process -FilePath $shell -ArgumentList $launchArgs -WindowStyle Normal|Out-Null
        $connect.Enabled=$false
    }catch{$script:autoOpen=$false;Show-Error $_.Exception.Message}
})
$check.Add_Click({if($script:sessionDir){[IO.File]::WriteAllText((Join-Path $script:sessionDir 'check'),'check');$detail.Text='正在从服务器重新检测外网，请稍候…'}})
$stop.Add_Click({
    try{if($script:sessionDir){
        [IO.File]::WriteAllText((Join-Path $script:sessionDir 'stop'),'stop');$script:autoOpen=$false
        $s=Read-JsonFile (Join-Path $script:sessionDir 'state.json')
        if($s -and -not(Test-OwnedProcess $s 'Worker') -and(Test-OwnedProcess $s 'Ssh')){Stop-Process -Id $s.SshPid}
        $status.Text='正在断开本工具的代理通道，不会停止训练。'
    }}catch{Show-Error $_.Exception.Message}
})
$timer=[Windows.Forms.Timer]::new();$timer.Interval=700
$timer.Add_Tick({
    try{
        if($script:discovery){
            $d=Read-JsonFile $script:discovery
            if($d){
                $proxyLabel.Text=$d.Message
                $codeStatus=if($d.CodePath -or $script:codePath){'VS Code 已找到'}else{'未找到 VS Code（请安装或在高级设置选择）'}
                $sshStatus=if($d.SshAvailable){'SSH 已就绪'}else{'未找到 OpenSSH 客户端，请在 Windows 可选功能安装'}
                $softwareLabel.Text="$codeStatus  ·  $sshStatus"
                if($d.Phase -in @('done','error')){
                    if($d.Port){$script:proxyPort=[int]$d.Port;$script:savedPort=[int]$d.Port}else{$script:proxyPort=0}
                    $proxyLabel.ForeColor=if($d.Verified){[Drawing.Color]::DarkGreen}else{[Drawing.Color]::FromArgb(150,85,0)}
                    if(-not $script:codePath -and $d.CodePath){$script:codePath=$d.CodePath}
                    $script:discovery=$null;$detect.Enabled=$true;$connect.Enabled=$true;$advanced.Enabled=$true
                }
            }
            if($script:discovery -and $script:detectProcess.HasExited -and (-not $d -or $d.Phase -eq 'scanning')){
                $script:discovery=$null;$detect.Enabled=$true;$connect.Enabled=$true;$advanced.Enabled=$true
                $proxyLabel.Text='检测进程未完成。请重试，或使用高级设置。'
            }
        }
        if(-not $script:sessionDir){$stop.Enabled=$false;$check.Enabled=$false;return}
        $s=Read-JsonFile (Join-Path $script:sessionDir 'state.json')
        if(-not $s){if($script:launchAt -and ((Get-Date)-$script:launchAt).TotalSeconds -gt 15){$status.Text='启动未完成，请查看 SSH 窗口。';$connect.Enabled=$true};return}
        $workerAlive=Test-OwnedProcess $s 'Worker';$sshAlive=Test-OwnedProcess $s 'Ssh'
        $active=$workerAlive -and $s.Phase -notin @('error','stopped');$script:connected=$active -or $sshAlive
        foreach($box in $script:controls.Values){$box.ReadOnly=$script:connected}
        $connect.Enabled=-not($script:connected -or $script:discovery);$stop.Enabled=$script:connected
        $check.Enabled=$active -and $s.Phase -in @('ready','degraded')
        $detect.Enabled=-not($script:connected -or $script:discovery);$advanced.Enabled=$detect.Enabled
        $status.Text=$s.Message
        if(-not $workerAlive -and $s.Phase -notin @('error','stopped')){$status.Text='SSH 控制窗口已关闭。请点“断开”清理后重新连接。';$script:autoOpen=$false}
        $status.BackColor=if($active -and $s.Phase -eq 'ready'){[Drawing.Color]::FromArgb(218,241,228)}else{[Drawing.Color]::FromArgb(231,237,247)}
        if($s.CheckedAt){$detail.Text="最近检测 $($s.CheckedAt)：HTTP $($s.Http)。连接后可在 VS Code 中选择文件夹。"}
        if($script:autoOpen -and $active -and $s.Phase -in @('ready','degraded')){$script:autoOpen=$false;Open-Server $script:activeConfig}
        if($s.Phase -in @('error','stopped')){$script:autoOpen=$false}
    }catch{$detail.Text=$_.Exception.Message}
})
$timer.Start()
if($SmokeTest){Write-Output "GUI v2 constructed: $($form.Controls.Count) controls; project field removed; SSH advanced only"}
else{
    $form.Add_Shown({if(-not $script:connected){try{Begin-Detection}catch{Show-Error $_.Exception.Message}}})
    [void]$form.ShowDialog()
}
$timer.Stop();$timer.Dispose();$form.Dispose();$script:mutex.ReleaseMutex();$script:mutex.Dispose()
