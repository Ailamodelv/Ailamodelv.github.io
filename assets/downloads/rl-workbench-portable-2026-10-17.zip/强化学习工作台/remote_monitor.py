"""Read-only remote health monitor. Sent in memory over the authenticated SSH session."""
import json
import select
import subprocess
import sys
import time

port = int(sys.argv[1])


def emit(event, **values):
    print(json.dumps(dict(event=event, **values)), flush=True)


def check():
    try:
        result = subprocess.run(
            ['curl', '--noproxy', '', '--proxy', f'http://127.0.0.1:{port}',
             '--connect-timeout', '6', '--max-time', '12', '-sS', '-o', '/dev/null',
             '-w', '%{http_code}', 'https://api.githubcopilot.com/_ping'],
            capture_output=True, text=True, timeout=16,
        )
        code = result.stdout.strip()
        emit('checked', ok=result.returncode == 0 and code == '200',
             http=code, message=result.stderr.strip()[:600])
    except Exception as exc:
        emit('checked', ok=False, http='', message=str(exc)[:600])


emit('connected')
check()
while True:
    readable, _, _ = select.select([sys.stdin], [], [], 20)
    if readable:
        line = sys.stdin.readline()
        if not line:
            break
        if line.strip() == 'check':
            check()
    else:
        emit('heartbeat')
