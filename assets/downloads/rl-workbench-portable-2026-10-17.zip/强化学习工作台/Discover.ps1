param([Parameter(Mandatory=$true)][string]$OutputPath,[int]$SavedPort=0)
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Common.ps1"
$result=[ordered]@{Phase='scanning';Message='正在查找当前电脑的代理…';Port=0;Source='';Http='';Verified=$false;CodePath='';SshAvailable=$false;CurlAvailable=$false;ListeningPorts=@();Diagnostics=@();RevocationFallback=$false}
$configuredCandidate=$null
try {
    $result.CodePath=[string](Find-CodeExecutable)
    $result.SshAvailable=Test-Path -LiteralPath "$env:WINDIR\System32\OpenSSH\ssh.exe"
    $curl=Join-Path $env:WINDIR 'System32\curl.exe'
    $result.CurlAvailable=Test-Path -LiteralPath $curl
    Write-JsonFile $OutputPath $result
    foreach($candidate in @(Get-ProxyCandidates $SavedPort)) {
        $tcp=[Net.Sockets.TcpClient]::new()
        try { $task=$tcp.ConnectAsync('127.0.0.1',$candidate.Port); $open=$task.Wait(350) -and $tcp.Connected } catch { $open=$false } finally { $tcp.Dispose() }
        if(-not $open){continue}
        $result.ListeningPorts+=@($candidate.Port)
        if(-not $configuredCandidate -and $candidate.Source -in @('Windows 系统代理','代理环境变量','当前电脑上次使用')) { $configuredCandidate=$candidate }
        $result.Message="正在验证本机端口 $($candidate.Port)…"
        Write-JsonFile $OutputPath $result
        if(-not $result.CurlAvailable){continue}
        # HTTPS via explicit HTTP proxy proves this is usable as a proxy, not merely an open port.
        $info=[Diagnostics.ProcessStartInfo]::new()
        $info.FileName=$curl
        $baseArguments="--noproxy localhost,127.0.0.1 --proxy http://127.0.0.1:$($candidate.Port) --connect-timeout 8 --max-time 15 -sS -o NUL -w %{http_code} https://api.githubcopilot.com/_ping"
        $info.Arguments=$baseArguments
        $info.UseShellExecute=$false; $info.CreateNoWindow=$true
        $info.RedirectStandardOutput=$true; $info.RedirectStandardError=$true
        for($attempt=0;$attempt -lt 2;$attempt++) {
            $p=[Diagnostics.Process]::new(); $p.StartInfo=$info
            try {
                [void]$p.Start()
                $stdout=$p.StandardOutput.ReadToEndAsync(); $stderr=$p.StandardError.ReadToEndAsync()
                if(-not $p.WaitForExit(17000)){ $p.Kill(); $p.WaitForExit() }
                $http=$stdout.GetAwaiter().GetResult().Trim()
                $errorText=$stderr.GetAwaiter().GetResult().Trim()
                if($p.ExitCode -eq 0 -and $http -eq '200') {
                    $result.Port=$candidate.Port; $result.Source=$candidate.Source; $result.Http=$http; $result.Verified=$true
                    $result.Message="已识别代理 127.0.0.1:$($candidate.Port)；外网检测通过"
                    break
                }
                if($attempt -eq 0 -and $errorText -match 'CRYPT_E_REVOCATION_OFFLINE') {
                    $info.Arguments=$baseArguments+' --ssl-revoke-best-effort'
                    $result.RevocationFallback=$true
                } elseif($attempt -eq 0 -and $p.ExitCode -eq 28) {
                    $result.Message="端口 $($candidate.Port) 暂时超时，正在重试…"
                    Write-JsonFile $OutputPath $result
                } else {
                    $result.Diagnostics+=@([pscustomobject]@{Port=$candidate.Port;Http=$http;Exit=$p.ExitCode;Error=$errorText})
                    break
                }
            } finally {$p.Dispose()}
        }
        if($result.Verified){break}
    }
    $result.Phase='done'
    if(-not $result.Verified){
        if($configuredCandidate){
            $result.Port=$configuredCandidate.Port;$result.Source=$configuredCandidate.Source
            $result.Message="已从$($configuredCandidate.Source)识别端口 $($configuredCandidate.Port)，但外网测试未通过。可重试或连接后复测。"
        }else{$result.Message='没有找到验证通过的 HTTP 代理。请打开代理软件后重试，或在高级设置手动指定端口。'}
    }
} catch { $result.Phase='error'; $result.Message=$_.Exception.Message }
Write-JsonFile $OutputPath $result
