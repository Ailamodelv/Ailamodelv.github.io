param([Parameter(Mandatory=$true)][string]$SessionDir)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\Common.ps1"
$statePath = Join-Path $SessionDir 'state.json'
$state = [ordered]@{ Phase='starting'; Message='请在 SSH 窗口本地输入密码'; WorkerPid=$PID; WorkerStart=(Get-Process -Id $PID).StartTime.ToUniversalTime().Ticks.ToString(); SshPid=0; SshStart=''; LastSeen=''; CheckedAt=''; Http=''; ProxyOk=$false }
function Publish-State { $state.LastSeen=[DateTime]::UtcNow.ToString('o'); Write-JsonFile $statePath $state }
$sshProcess = $null
try {
    $Host.UI.RawUI.WindowTitle = 'RL Workbench - SSH login / KEEP OPEN'
    $config = Read-JsonFile (Join-Path $SessionDir 'config.json')
    Assert-Config $config
    Test-LocalProxy $config.ProxyPort
    if ((Get-ConflictingTunnel $config).Count) { throw '已有其他 SSH 通道使用这个转发入口；先在原窗口关闭旧通道。' }
    $sshExe = Join-Path $env:WINDIR 'System32\OpenSSH\ssh.exe'
    if (-not (Test-Path -LiteralPath $sshExe)) { throw '未找到 Windows OpenSSH 客户端。' }
    $source = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'remote_monitor.py'))
    $payload = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($source))
    $remoteCommand = "python3 -u -c 'import base64;exec(base64.b64decode(`"$payload`"))' $($config.RemotePort)"
    $arguments = Get-SshArguments $config $remoteCommand
    $startInfo = [Diagnostics.ProcessStartInfo]::new()
    $startInfo.FileName = $sshExe
    $startInfo.Arguments = ($arguments | ForEach-Object { Quote-WindowsArgument $_ }) -join ' '
    $startInfo.UseShellExecute = $false
    $startInfo.RedirectStandardInput = $true
    $startInfo.RedirectStandardOutput = $true
    # Leave stderr and the console available for native SSH password / host-key prompts.
    Write-Host 'RL Workbench: enter your SSH password locally when prompted.'
    Write-Host "Server: $($config.User)@$($config.Server):$($config.SshPort)"
    Write-Host "Linux $($config.RemotePort) -> this computer $($config.ProxyPort)"
    Write-Host 'For a new host key, verify its fingerprint with your administrator.'
    Write-Host 'Keep this window open. Use Disconnect in the workbench to stop.'
    Publish-State
    $sshProcess = [Diagnostics.Process]::new()
    $sshProcess.StartInfo = $startInfo
    [void]$sshProcess.Start()
    $state.SshPid=$sshProcess.Id
    $state.SshStart=$sshProcess.StartTime.ToUniversalTime().Ticks.ToString()
    Publish-State
    $readTask = $sshProcess.StandardOutput.ReadLineAsync()
    $lastPublish = Get-Date
    while (-not $sshProcess.HasExited) {
        if (Test-Path -LiteralPath (Join-Path $SessionDir 'stop')) { break }
        if (Test-Path -LiteralPath (Join-Path $SessionDir 'check')) {
            Remove-Item -LiteralPath (Join-Path $SessionDir 'check')
            $sshProcess.StandardInput.WriteLine('check')
            $sshProcess.StandardInput.Flush()
        }
        if ($readTask.IsCompleted) {
            $line = $readTask.GetAwaiter().GetResult()
            if ($null -eq $line) { break }
            try { $eventData = $line | ConvertFrom-Json -ErrorAction Stop } catch { $eventData = $null }
            if ($eventData -and $eventData.event -eq 'connected') {
                $state.Phase='checking'; $state.Message='SSH 已登录，正在验证服务器经当前电脑访问外网'
            } elseif ($eventData -and $eventData.event -eq 'checked') {
                $state.ProxyOk=[bool]$eventData.ok; $state.Http=[string]$eventData.http; $state.CheckedAt=(Get-Date).ToString('HH:mm:ss')
                if ($state.ProxyOk) { $state.Phase='ready'; $state.Message='代理通道验证通过（Copilot HTTP 200）' }
                else { $state.Phase='degraded'; $state.Message="SSH 已连通，外网检测未通过：HTTP $($eventData.http) $($eventData.message)" }
            }
            Publish-State
            $readTask = $sshProcess.StandardOutput.ReadLineAsync()
        }
        if (((Get-Date)-$lastPublish).TotalSeconds -ge 3) { Publish-State; $lastPublish=Get-Date }
        Start-Sleep -Milliseconds 150
    }
    if (Test-Path -LiteralPath (Join-Path $SessionDir 'stop')) { $state.Message='已断开本工具创建的通道' }
    else { $state.Message='SSH 已退出；请检查密码、端口占用或 SSH 窗口错误，然后重新连接' }
    $state.Phase='stopped'
} catch {
    $state.Phase='error'; $state.Message=$_.Exception.Message
    Write-Host $state.Message -ForegroundColor Red
} finally {
    if ($sshProcess) {
        try { if (-not $sshProcess.HasExited) { $sshProcess.Kill(); $sshProcess.WaitForExit(3000) | Out-Null } } catch {}
        $sshProcess.Dispose()
    }
    Publish-State
}
