import contextlib
import io
import json
import pathlib
import runpy
import subprocess
import sys
from unittest.mock import patch

script = pathlib.Path(__file__).with_name('remote_monitor.py')
for code, returncode, expected in [('200', 0, True), ('000', 7, False), ('403', 0, False)]:
    output = io.StringIO()
    result = subprocess.CompletedProcess([], returncode, code, 'failure' if returncode else '')
    with patch.object(sys, 'argv', [str(script), '17890']), \
         patch.object(sys, 'stdin', io.StringIO('check\n')), \
         patch('select.select', side_effect=lambda r, w, x, t: (r, [], [])), \
         patch('subprocess.run', return_value=result) as run, contextlib.redirect_stdout(output):
        runpy.run_path(str(script))
    events = [json.loads(line) for line in output.getvalue().splitlines()]
    assert events[0]['event'] == 'connected'
    assert len(events) == 3  # initial test, then explicit recheck
    assert events[1]['ok'] is expected and events[2]['ok'] is expected
    assert 'http://127.0.0.1:17890' in run.call_args.args[0]
print('PASS: remote monitor initial check / recheck / HTTP 200, 403 and connection-failure classification (mocked).')
