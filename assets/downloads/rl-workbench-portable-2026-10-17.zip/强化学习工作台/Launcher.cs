using System;
using System.IO;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Threading;
using System.Windows.Forms;

internal static class Launcher
{
    [STAThread]
    private static void Main()
    {
        try
        {
            // Equivalent to powershell.exe -ExecutionPolicy Bypass for this process only.
            // Does not change the user's or machine's persisted execution policy.
            Environment.SetEnvironmentVariable("PSExecutionPolicyPreference", "Bypass", EnvironmentVariableTarget.Process);
            string script = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "App.ps1");
            using (Runspace runspace = RunspaceFactory.CreateRunspace())
            {
                runspace.ApartmentState = ApartmentState.STA;
                runspace.ThreadOptions = PSThreadOptions.UseCurrentThread;
                runspace.Open();
                using (PowerShell powershell = PowerShell.Create())
                {
                    powershell.Runspace = runspace;
                    // The local script contains the UI; no network download or stored password.
                    powershell.AddCommand(script);
                    powershell.Invoke();
                    if (powershell.HadErrors)
                        throw new InvalidOperationException(powershell.Streams.Error[0].ToString());
                }
            }
        }
        catch (Exception error)
        {
            try { string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "RLWorkbench"); Directory.CreateDirectory(dir); File.WriteAllText(Path.Combine(dir, "startup-error.txt"), error.ToString()); } catch { }
            MessageBox.Show(error.Message, "强化学习工作台 - 启动失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
