$ErrorActionPreference='Stop'
. "$PSScriptRoot\Common.ps1"
function Assert($Condition,$Message) { if (-not $Condition) { throw $Message } }
$cfg=Read-JsonFile "$PSScriptRoot\defaults.json"
$cfg | Add-Member -NotePropertyName ProxyPort -NotePropertyValue 7897
Assert-Config $cfg
$testRoot=Join-Path ([IO.Path]::GetTempPath()) ('rl-workbench-test-'+[Guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($testRoot)
$configFile=Join-Path $testRoot 'config'
$original="Host retained`n  HostName 192.0.2.10`n  User original`n"
[IO.File]::WriteAllText($configFile,$original)
$alias=Ensure-WorkbenchHost $cfg $configFile
$after=[IO.File]::ReadAllText($configFile)
Assert ($after.EndsWith($original)) 'Original SSH content changed'
Assert (@(Get-ChildItem -LiteralPath $testRoot -Filter '*.bak').Count -eq 1) 'Backup missing'
[void](Ensure-WorkbenchHost $cfg $configFile)
Assert ([IO.File]::ReadAllText($configFile) -eq $after) 'Duplicate alias was added'
$effective=& "$env:WINDIR\System32\OpenSSH\ssh.exe" -G -F $configFile $alias 2>$null
Assert ($effective -contains "hostname $($cfg.Server)") 'HostName mismatch'
Assert ($effective -contains "user $($cfg.User)") 'SSH user mismatch'
Assert ($effective -contains "port $($cfg.SshPort)") 'SSH port mismatch'
$codeArgs=@(Get-CodeArguments $alias)
Assert ($codeArgs.Count -eq 3 -and $codeArgs[2] -eq "ssh-remote+$alias") 'Remote window arguments failed'
Assert ($codeArgs -notcontains '--folder-uri') 'Project directory should not be required'
$ports=@(Get-LoopbackProxyPort 'http=127.0.0.1:7897;https=localhost:8080;socks=127.0.0.1:1080')
Assert ($ports.Count -eq 2 -and $ports[0] -eq 7897 -and $ports[1] -eq 8080) 'System proxy parsing failed'
Assert (@(Get-LoopbackProxyPort 'http://user:secret@127.0.0.1:7897').Count -eq 0) 'Credential endpoint should not be read'
Assert (@(Get-LoopbackProxyPort 'http://192.0.2.1:7897').Count -eq 0) 'Non-local endpoint should not be selected'
Assert (@(Get-LoopbackProxyPort 'socks5://127.0.0.1:1080').Count -eq 0) 'SOCKS endpoint should not be assumed HTTP'
$cfg.ProxyPort=0
Assert-Config $cfg -AllowUndetectedProxy
$missingRejected=$false
try {Assert-Config $cfg} catch {$missingRejected=$true}
Assert $missingRejected 'Connecting without a detected proxy should fail'
$cfg.ProxyPort=7897
Assert ((Quote-WindowsArgument 'C:\space dir\') -eq '"C:\space dir\\"') 'Trailing slash quoting failed'
Assert (-not (Test-OwnedProcess ([pscustomobject]@{SshPid=$PID;SshStart='0'}) 'Ssh')) 'PID-reuse protection failed'
$cfg.Server='example.com;whoami'
$rejected=$false
try { Assert-Config $cfg } catch { $rejected=$true }
Assert $rejected 'Unsafe server accepted'
$cfg.Server='example.com'; $cfg.ProxyPort=70000
$rejected=$false
try { Assert-Config $cfg } catch { $rejected=$true }
Assert $rejected 'Invalid port accepted'
'PASS: validation, SSH backup/preservation/idempotence, effective Host, project-free remote window, proxy parsing, undetected-proxy guard, quoting, PID identity.'
"Temporary test files: $testRoot"
